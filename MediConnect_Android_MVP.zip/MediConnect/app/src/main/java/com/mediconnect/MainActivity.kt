package com.mediconnect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF123B5D)
private val Teal = Color(0xFF16A6A1)
private val Pale = Color(0xFFF3F8FB)
private val Ink = Color(0xFF1D2D3A)

data class Doctor(val name: String, val specialty: String, val experience: String, val fee: String, val initials: String)
data class Appointment(val doctor: String, val specialty: String, val date: String, val time: String, val status: String)

private val doctors = listOf(
    Doctor("Dr. Ananya Rao", "Cardiologist", "12 years experience", "₹600", "AR"),
    Doctor("Dr. Vikram Mehta", "Dermatologist", "9 years experience", "₹450", "VM"),
    Doctor("Dr. Priya Sharma", "Pediatrician", "15 years experience", "₹550", "PS"),
    Doctor("Dr. Arjun Reddy", "General Physician", "8 years experience", "₹350", "AR")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediConnectApp() }
    }
}

@Composable
fun MediConnectApp() {
    var isDoctor by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedDoctor by remember { mutableStateOf<Doctor?>(null) }
    var bookingMessage by remember { mutableStateOf("") }
    var chatText by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Hello! How can I help you today?")) }
    var appointments by remember {
        mutableStateOf(listOf(Appointment("Dr. Ananya Rao", "Cardiology", "12 Nov 2026", "10:30 AM", "Confirmed")))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Teal, background = Pale, surface = Color.White)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
            Column {
                TopBar(isDoctor, onRoleChange = { isDoctor = it; selectedTab = "Home" })
                if (selectedDoctor != null) {
                    BookingScreen(
                        doctor = selectedDoctor!!,
                        onBack = { selectedDoctor = null },
                        onBook = { date, time ->
                            appointments = appointments + Appointment(
                                selectedDoctor!!.name, selectedDoctor!!.specialty, date, time, "Requested"
                            )
                            bookingMessage = "Appointment request sent for $date at $time."
                            selectedDoctor = null
                            selectedTab = "Appointments"
                        }
                    )
                } else {
                    when (selectedTab) {
                        "Home" -> if (isDoctor) DoctorHome(appointments) else PatientHome(
                            appointments = appointments,
                            onFindDoctor = { selectedTab = "Doctors" },
                            onBook = { selectedDoctor = it }
                        )
                        "Doctors" -> DoctorDirectory(onBook = { selectedDoctor = it })
                        "Appointments" -> AppointmentsScreen(appointments, bookingMessage)
                        "Messages" -> ChatScreen(
                            messages = messages, text = chatText,
                            onTextChange = { chatText = it },
                            onSend = {
                                if (chatText.isNotBlank()) {
                                    messages = messages + chatText.trim()
                                    chatText = ""
                                }
                            }
                        )
                        else -> ProfileScreen(isDoctor)
                    }
                    NavigationBar(containerColor = Color.White) {
                        val tabs = listOf("Home", "Doctors", "Appointments", "Messages", "Profile")
                        val icons = listOf(Icons.Default.Home, Icons.Default.MedicalServices, Icons.Default.CalendarMonth, Icons.Default.Chat, Icons.Default.Person)
                        tabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = { Icon(icons[index], contentDescription = tab) },
                                label = { Text(tab, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(isDoctor: Boolean, onRoleChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("MediConnect", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Care that connects", color = Color(0xFFD5E7F2), fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isDoctor) "Doctor" else "Patient", color = Color.White, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Switch(checked = isDoctor, onCheckedChange = onRoleChange)
        }
    }
}

@Composable
fun PatientHome(appointments: List<Appointment>, onFindDoctor: () -> Unit, onBook: (Doctor) -> Unit) {
    LazyColumn(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Good morning 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Your health, one step at a time.", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Need medical advice?", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Connect with a doctor from wherever you are.", color = Color(0xFFD5E7F2))
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onFindDoctor, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                        Text("Find a doctor")
                    }
                }
            }
        }
        item { SectionTitle("Upcoming appointment") }
        if (appointments.isEmpty()) {
            item { Text("No appointments yet. Book a consultation to get started.", color = Color.Gray) }
        } else {
            item { AppointmentCard(appointments.last()) }
        }
        item { SectionTitle("Popular specialists") }
        items(doctors.take(3)) { doctor -> DoctorCard(doctor, onClick = { onBook(doctor) }) }
    }
}

@Composable
fun DoctorHome(appointments: List<Appointment>) {
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Doctor dashboard", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Welcome back. Here is your schedule.", color = Color.Gray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Appointments", appointments.size.toString(), Modifier.weight(1f))
                MetricCard("Pending", appointments.count { it.status == "Requested" }.toString(), Modifier.weight(1f))
            }
        }
        item { SectionTitle("Patient appointments") }
        if (appointments.isEmpty()) item { Text("No appointments to show.", color = Color.Gray) }
        items(appointments.reversed()) { AppointmentCard(it) }
        item { Text("Demo mode: appointment data is stored only while the app is open.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(label, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun DoctorDirectory(onBook: (Doctor) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = doctors.filter { it.name.contains(query, true) || it.specialty.contains(query, true) }
    Column(Modifier.weight(1f).fillMaxWidth().padding(18.dp)) {
        Text("Find a doctor", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search name or specialty") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { DoctorCard(it, onClick = { onBook(it) }) }
        }
    }
}

@Composable
fun DoctorCard(doctor: Doctor, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(Color(0xFFDDF3F1), CircleShape), contentAlignment = Alignment.Center) {
                Text(doctor.initials, color = Navy, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(doctor.name, fontWeight = FontWeight.Bold, color = Ink)
                Text(doctor.specialty, color = Teal, fontSize = 13.sp)
                Text(doctor.experience, color = Color.Gray, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(doctor.fee, fontWeight = FontWeight.Bold, color = Navy)
                Text("per visit", color = Color.Gray, fontSize = 10.sp)
                Text("Book", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun BookingScreen(doctor: Doctor, onBack: () -> Unit, onBook: (String, String) -> Unit) {
    var date by remember { mutableStateOf("12 Nov 2026") }
    var time by remember { mutableStateOf("10:30 AM") }
    Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("← Back", color = Teal, modifier = Modifier.clickable { onBack() })
        Text("Book consultation", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        DoctorCard(doctor, onClick = {})
        Text("Choose a date", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(date, { date = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Date") })
        Text("Choose a time", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("10:30 AM", "12:00 PM", "4:00 PM").forEach {
                FilterChip(selected = time == it, onClick = { time = it }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onBook(date, time) }, modifier = Modifier.fillMaxWidth()) {
            Text("Request appointment")
        }
        Text("This demo does not confirm real doctor availability or process payments.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun AppointmentsScreen(appointments: List<Appointment>, message: String) {
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Appointments", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink) }
        if (message.isNotBlank()) item { Text(message, color = Teal, fontSize = 13.sp) }
        if (appointments.isEmpty()) item { Text("You have no appointments yet.", color = Color.Gray) }
        items(appointments.reversed()) { AppointmentCard(it) }
    }
}

@Composable
fun AppointmentCard(appointment: Appointment) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CalendarMonth, null, tint = Teal, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(appointment.doctor, fontWeight = FontWeight.Bold, color = Ink)
                Text(appointment.specialty, color = Color.Gray, fontSize = 12.sp)
                Text("${appointment.date} • ${appointment.time}", color = Navy, fontSize = 12.sp)
            }
            Text(appointment.status, color = Teal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ChatScreen(messages: List<String>, text: String, onTextChange: (String) -> Unit, onSend: () -> Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Text("Messages", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Demo conversation • Dr. Ananya Rao", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                    Surface(color = Color.White, shape = RoundedCornerShape(14.dp)) {
                        Text(msg, Modifier.padding(12.dp), color = Ink)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, onTextChange, modifier = Modifier.weight(1f), placeholder = { Text("Type a message") }, singleLine = true)
            IconButton(onClick = onSend) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Teal) }
        }
        Text("Demo only: messages are not sent to a real doctor.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun ProfileScreen(isDoctor: Boolean) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My profile", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Box(Modifier.size(76.dp).background(Color(0xFFDDF3F1), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(42.dp))
        }
        Text(if (isDoctor) "Demo Doctor" else "Demo Patient", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(if (isDoctor) "Healthcare professional" else "Patient account", color = Color.Gray)
        HorizontalDivider()
        ProfileRow("Personal information")
        ProfileRow("Consultation history")
        ProfileRow("Notifications")
        ProfileRow("Help and support")
        Text("Demo profile. Sign-in and secure account storage are not connected yet.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ProfileRow(label: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircle, null, tint = Teal)
        Spacer(Modifier.width(12.dp))
        Text(label, color = Ink)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
}
